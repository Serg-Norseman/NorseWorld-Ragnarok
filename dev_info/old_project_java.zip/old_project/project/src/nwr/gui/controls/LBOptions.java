/*
 *  "NorseWorld: Ragnarok", a roguelike game for PCs.
 *  Copyright (C) 2002-2008, 2014 by Serg V. Zhdanovskih (aka Alchemist).
 *
 *  This file is part of "NorseWorld: Ragnarok".
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package nwr.gui.controls;

/**
 *
 * @author Serg V. Zhdanovskih
 */
public final class LBOptions extends jzrlib.core.FlagSet
{
    public static final int lboChecks = 0;
    public static final int lboIcons = 1;
    public static final int lboTextTop = 2;
    public static final int lboRadioChecks = 3;
    public static final int lboDoubleItem = 4;

    public LBOptions(int... args)
    {
        super(args);
    }
}
